INSTRUCTIONS FOR SETTING UP THE APPLICATION:

1) Unzip the GROUP_23.zip file

2) Open graphDB and create a new repository called "Marvel" using the OWL-MAX(optimized) ruleset.

3) Upload the Marvel.ttl file into the new repository

4) Turn on the Moesif CORS plug-in on your webbrowser
You will be able to find this plug-in through the following link: https://chrome.google.com/webstore/detail/moesif-origin-cors-change/digfbfaphojjndkpccljibejjbppifbc?hl=nl

5) Launch the application by opening the index.html file

* Importantly, on the Movies-page when searching for all the movies or sorting by a specific character, it takes some time to precess the query and display the results

